import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export function ClockTower({ isHovered, onHotspotClick, activeHotspot }) {
  const towerRef = useRef();
  const gearsGroupRef = useRef();
  const pendulumRef = useRef();
  const minuteHandRef = useRef();
  const hourHandRef = useRef();
  const secondHandRef = useRef();

  // Procedural Materials
  const basaltMaterial = new THREE.MeshStandardMaterial({
    color: '#1a1917',
    roughness: 0.85,
    metalness: 0.2,
  });

  const ablaqWhiteMaterial = new THREE.MeshStandardMaterial({
    color: '#d6cbb5',
    roughness: 0.7,
    metalness: 0.1,
  });

  const copperBronzeMaterial = new THREE.MeshStandardMaterial({
    color: '#b45309',
    roughness: 0.35,
    metalness: 0.85,
  });

  const brassGearMaterial = new THREE.MeshStandardMaterial({
    color: '#d97706',
    roughness: 0.25,
    metalness: 0.9,
  });

  const clockFaceMaterial = new THREE.MeshStandardMaterial({
    color: '#fef3c7',
    roughness: 0.3,
    emissive: '#78350f',
    emissiveIntensity: 0.4,
  });

  const clockHandMaterial = new THREE.MeshStandardMaterial({
    color: '#09090b',
    roughness: 0.2,
    metalness: 0.9,
  });

  const glassMaterial = new THREE.MeshPhysicalMaterial({
    color: '#fef08a',
    transmission: 0.6,
    opacity: 0.8,
    transparent: true,
    roughness: 0.2,
    ior: 1.5,
  });

  // Animation Loop: Gear rotations, hands ticking, pendulum swinging
  useFrame((state, delta) => {
    const time = state.clock.getElapsedTime();

    // Internal gears rotation
    if (gearsGroupRef.current) {
      gearsGroupRef.current.children.forEach((gear, idx) => {
        gear.rotation.z += (idx % 2 === 0 ? 1 : -1) * delta * 0.8;
      });
    }

    // Pendulum swing
    if (pendulumRef.current) {
      pendulumRef.current.rotation.z = Math.sin(time * 3) * 0.15;
    }

    // Live Clock Hands Rotation
    if (secondHandRef.current) {
      secondHandRef.current.rotation.z = -time * 0.5;
    }
    if (minuteHandRef.current) {
      minuteHandRef.current.rotation.z = -time * 0.05;
    }
    if (hourHandRef.current) {
      hourHandRef.current.rotation.z = -time * 0.005;
    }

    // Subtle breathing animation for whole tower when idle
    if (towerRef.current) {
      towerRef.current.rotation.y = Math.sin(time * 0.3) * 0.03;
    }
  });

  return (
    <group ref={towerRef} position={[0, -0.5, 0]}>
      {/* 1. Basalt Base Foundation */}
      <mesh position={[0, -2.5, 0]} material={basaltMaterial} castShadow receiveShadow>
        <boxGeometry args={[2.2, 1.8, 2.2]} />
      </mesh>

      {/* Base Steps & Mouldings */}
      <mesh position={[0, -3.5, 0]} material={basaltMaterial} castShadow receiveShadow>
        <boxGeometry args={[2.8, 0.4, 2.8]} />
      </mesh>
      <mesh position={[0, -3.8, 0]} material={basaltMaterial} receiveShadow>
        <boxGeometry args={[3.4, 0.3, 3.4]} />
      </mesh>

      {/* 2. Main Tower Shaft - Ablaq (Alternating Dark Basalt & Light Stone Bands) */}
      <group position={[0, -0.2, 0]}>
        {[...Array(8)].map((_, i) => (
          <mesh
            key={i}
            position={[0, -1.2 + i * 0.35, 0]}
            material={i % 2 === 0 ? basaltMaterial : ablaqWhiteMaterial}
            castShadow
            receiveShadow
          >
            <boxGeometry args={[1.8, 0.34, 1.8]} />
          </mesh>
        ))}
      </group>

      {/* 3. Balcony & Decorative Arches */}
      <mesh position={[0, 1.35, 0]} material={copperBronzeMaterial} castShadow>
        <boxGeometry args={[2.1, 0.15, 2.1]} />
      </mesh>
      {/* Balcony Railings / Fence */}
      <mesh position={[0, 1.55, 0]} material={copperBronzeMaterial} castShadow>
        <boxGeometry args={[2.0, 0.25, 2.0]} />
      </mesh>

      {/* 4. Upper Clock Housing (4 Faces) */}
      <mesh position={[0, 2.3, 0]} material={basaltMaterial} castShadow receiveShadow>
        <boxGeometry args={[1.7, 1.5, 1.7]} />
      </mesh>

      {/* 4 Clock Dial Faces (Front, Back, Left, Right) */}
      {/* Front Face */}
      <group position={[0, 2.3, 0.86]}>
        <mesh material={clockFaceMaterial}>
          <cylinderGeometry args={[0.55, 0.55, 0.05, 32]} rotation={[Math.PI / 2, 0, 0]} />
        </mesh>
        {/* Bronze Dial Ring */}
        <mesh material={copperBronzeMaterial} position={[0, 0, 0.01]}>
          <ringGeometry args={[0.52, 0.58, 32]} />
        </mesh>

        {/* Hands */}
        <group position={[0, 0, 0.04]}>
          <mesh ref={hourHandRef} material={clockHandMaterial} position={[0, 0.12, 0]}>
            <boxGeometry args={[0.04, 0.28, 0.02]} />
          </mesh>
          <mesh ref={minuteHandRef} material={clockHandMaterial} position={[0, 0.18, 0.01]}>
            <boxGeometry args={[0.03, 0.4, 0.02]} />
          </mesh>
          <mesh ref={secondHandRef} material={copperBronzeMaterial} position={[0, 0.2, 0.02]}>
            <boxGeometry args={[0.015, 0.45, 0.01]} />
          </mesh>
          {/* Central Pin */}
          <mesh material={copperBronzeMaterial} position={[0, 0, 0.03]}>
            <sphereGeometry args={[0.04, 16, 16]} />
          </mesh>
        </group>
      </group>

      {/* Back Face */}
      <group position={[0, 2.3, -0.86]} rotation={[0, Math.PI, 0]}>
        <mesh material={clockFaceMaterial}>
          <cylinderGeometry args={[0.55, 0.55, 0.05, 32]} rotation={[Math.PI / 2, 0, 0]} />
        </mesh>
        <mesh material={copperBronzeMaterial} position={[0, 0, 0.01]}>
          <ringGeometry args={[0.52, 0.58, 32]} />
        </mesh>
      </group>

      {/* Right Face */}
      <group position={[0.86, 2.3, 0]} rotation={[0, Math.PI / 2, 0]}>
        <mesh material={clockFaceMaterial}>
          <cylinderGeometry args={[0.55, 0.55, 0.05, 32]} rotation={[Math.PI / 2, 0, 0]} />
        </mesh>
        <mesh material={copperBronzeMaterial} position={[0, 0, 0.01]}>
          <ringGeometry args={[0.52, 0.58, 32]} />
        </mesh>
      </group>

      {/* Left Face */}
      <group position={[-0.86, 2.3, 0]} rotation={[0, -Math.PI / 2, 0]}>
        <mesh material={clockFaceMaterial}>
          <cylinderGeometry args={[0.55, 0.55, 0.05, 32]} rotation={[Math.PI / 2, 0, 0]} />
        </mesh>
        <mesh material={copperBronzeMaterial} position={[0, 0, 0.01]}>
          <ringGeometry args={[0.52, 0.58, 32]} />
        </mesh>
      </group>

      {/* 5. Internal Gear Mechanism (Visible inside central chamber) */}
      <group position={[0, 1.0, 0]}>
        {/* Glass Chamber Window */}
        <mesh material={glassMaterial} castShadow>
          <boxGeometry args={[1.2, 1.0, 1.2]} />
        </mesh>

        {/* Spinning Brass Cogwheels */}
        <group ref={gearsGroupRef}>
          <mesh position={[-0.2, 0.1, 0]} material={brassGearMaterial}>
            <cylinderGeometry args={[0.3, 0.3, 0.05, 12]} rotation={[Math.PI / 2, 0, 0]} />
          </mesh>
          <mesh position={[0.2, -0.1, 0.1]} material={brassGearMaterial}>
            <cylinderGeometry args={[0.22, 0.22, 0.05, 10]} rotation={[Math.PI / 2, 0, 0]} />
          </mesh>
          <mesh position={[0.0, 0.25, -0.1]} material={brassGearMaterial}>
            <cylinderGeometry args={[0.18, 0.18, 0.05, 8]} rotation={[Math.PI / 2, 0, 0]} />
          </mesh>
        </group>

        {/* Pendulum */}
        <group ref={pendulumRef} position={[0, 0.4, 0]}>
          <mesh position={[0, -0.4, 0]} material={copperBronzeMaterial}>
            <cylinderGeometry args={[0.015, 0.015, 0.8, 8]} />
          </mesh>
          <mesh position={[0, -0.8, 0]} material={copperBronzeMaterial}>
            <cylinderGeometry args={[0.12, 0.12, 0.03, 16]} rotation={[Math.PI / 2, 0, 0]} />
          </mesh>
        </group>
      </group>

      {/* 6. Syrian Roof Canopy & Copper Spire Dome */}
      <mesh position={[0, 3.2, 0]} material={copperBronzeMaterial} castShadow>
        <coneGeometry args={[1.3, 0.8, 4]} rotation={[0, Math.PI / 4, 0]} />
      </mesh>
      <mesh position={[0, 3.8, 0]} material={copperBronzeMaterial} castShadow>
        <cylinderGeometry args={[0.08, 0.08, 0.6, 16]} />
      </mesh>
      {/* Crescent / Finial top ornament */}
      <mesh position={[0, 4.25, 0]} material={copperBronzeMaterial}>
        <sphereGeometry args={[0.12, 16, 16]} />
      </mesh>

      {/* Hotspots for Interactive Inspection */}
      {onHotspotClick && (
        <group>
          {/* Face Hotspot */}
          <mesh
            position={[0, 2.3, 1.0]}
            onClick={() => onHotspotClick('face')}
            cursor="pointer"
          >
            <sphereGeometry args={[0.12, 16, 16]} />
            <meshBasicMaterial color="#f59e0b" wireframe />
          </mesh>

          {/* Gears Hotspot */}
          <mesh
            position={[0.7, 1.0, 0.7]}
            onClick={() => onHotspotClick('gears')}
            cursor="pointer"
          >
            <sphereGeometry args={[0.12, 16, 16]} />
            <meshBasicMaterial color="#f59e0b" wireframe />
          </mesh>

          {/* Balcony / Canopy Hotspot */}
          <mesh
            position={[0, 3.2, 1.0]}
            onClick={() => onHotspotClick('balcony')}
            cursor="pointer"
          >
            <sphereGeometry args={[0.12, 16, 16]} />
            <meshBasicMaterial color="#f59e0b" wireframe />
          </mesh>

          {/* Base Hotspot */}
          <mesh
            position={[0, -2.5, 1.2]}
            onClick={() => onHotspotClick('base')}
            cursor="pointer"
          >
            <sphereGeometry args={[0.12, 16, 16]} />
            <meshBasicMaterial color="#f59e0b" wireframe />
          </mesh>
        </group>
      )}
    </group>
  );
}
