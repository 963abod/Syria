import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export function AtmosphericParticles({ count = 250, mousePos }) {
  const pointsRef = useRef();

  // Generate random 3D particle positions, scales, and velocities
  const [positions, scales] = useMemo(() => {
    const posArr = new Float32Array(count * 3);
    const scaleArr = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      posArr[i * 3] = (Math.random() - 0.5) * 18;
      posArr[i * 3 + 1] = (Math.random() - 0.5) * 14;
      posArr[i * 3 + 2] = (Math.random() - 0.5) * 18;

      scaleArr[i] = Math.random() * 0.08 + 0.02;
    }

    return [posArr, scaleArr];
  }, [count]);

  // Smooth Perlin-like motion for floating copper dust particles
  useFrame((state, delta) => {
    if (!pointsRef.current) return;
    const time = state.clock.getElapsedTime();
    const positions = pointsRef.current.geometry.attributes.position.array;

    for (let i = 0; i < count; i++) {
      const idx = i * 3;
      // Organic drifting logic
      positions[idx + 1] += Math.sin(time + i) * 0.003;
      positions[idx] += Math.cos(time * 0.8 + i) * 0.002;
      positions[idx + 2] += Math.sin(time * 0.5 + i) * 0.002;

      // Wrap around bounds
      if (positions[idx + 1] > 7) positions[idx + 1] = -7;
      if (positions[idx + 1] < -7) positions[idx + 1] = 7;
    }

    // React subtly to mouse parallax
    if (mousePos) {
      pointsRef.current.rotation.y = mousePos.x * 0.15;
      pointsRef.current.rotation.x = -mousePos.y * 0.1;
    } else {
      pointsRef.current.rotation.y = time * 0.02;
    }

    pointsRef.current.geometry.attributes.position.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.12}
        color="#f59e0b"
        transparent
        opacity={0.6}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
}

// Dynamic Volumetric Fog Planes with Organic Noise Movement
export function VolumetricFogPlanes({ mousePos }) {
  const fogGroupRef = useRef();

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (fogGroupRef.current) {
      fogGroupRef.current.children.forEach((plane, idx) => {
        plane.rotation.z = Math.sin(time * 0.2 + idx) * 0.1;
        plane.position.y = Math.sin(time * 0.3 + idx * 2) * 0.3 - 0.5;
        plane.position.x = Math.cos(time * 0.15 + idx) * 0.4;
      });

      if (mousePos) {
        fogGroupRef.current.rotation.y = mousePos.x * 0.2;
      }
    }
  });

  return (
    <group ref={fogGroupRef}>
      {[...Array(4)].map((_, i) => (
        <mesh key={i} position={[0, -0.5, -2 - i * 1.5]}>
          <planeGeometry args={[16, 10]} />
          <meshBasicMaterial
            color="#3b2b13"
            transparent
            opacity={0.15 - i * 0.03}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </mesh>
      ))}
    </group>
  );
}

// Cinematic Moving Spotlights with Warm Light Flicker
export function CinematicLighting({ mousePos }) {
  const spotlightRef = useRef();
  const fillLightRef = useRef();

  useFrame((state) => {
    const time = state.clock.getElapsedTime();

    // Subtle light intensity flickering (simulating realistic warm ambient glow)
    if (spotlightRef.current) {
      spotlightRef.current.intensity = 3.5 + Math.sin(time * 4) * 0.2 + (Math.random() - 0.5) * 0.1;
      if (mousePos) {
        spotlightRef.current.position.x = 5 + mousePos.x * 2;
        spotlightRef.current.position.y = 8 + mousePos.y * 2;
      }
    }

    if (fillLightRef.current) {
      fillLightRef.current.intensity = 1.2 + Math.cos(time * 2) * 0.1;
    }
  });

  return (
    <>
      <ambientLight intensity={0.4} color="#1e1b18" />
      {/* Key Warm Copper Spotlight */}
      <spotLight
        ref={spotlightRef}
        position={[5, 8, 6]}
        angle={0.6}
        penumbra={0.8}
        intensity={3.5}
        color="#fbbf24"
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />
      {/* Fill Cool Slate Light for Depth Contrast */}
      <spotLight
        ref={fillLightRef}
        position={[-6, 4, -4]}
        angle={0.8}
        penumbra={1.0}
        intensity={1.2}
        color="#38bdf8"
      />
      {/* Bottom Uplight for Tower Base */}
      <pointLight position={[0, -3.5, 3]} intensity={1.5} color="#d97706" distance={8} />
    </>
  );
}
