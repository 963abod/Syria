import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export function LoadingScreen({ onComplete, lang = 'ar' }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => onComplete(), 400);
          return 100;
        }
        return prev + Math.floor(Math.random() * 15) + 5;
      });
    }, 120);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <motion.div
      exit={{ opacity: 0, transition: { duration: 0.8, ease: 'easeInOut' } }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#08080a] text-center px-4"
    >
      {/* Metallic Logo Icon */}
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="w-20 h-20 mb-6 rounded-full border border-amber-500/30 flex items-center justify-center shadow-[0_0_30px_rgba(217,119,6,0.2)] bg-gradient-to-b from-[#1c1917] to-[#08080a]"
      >
        <span className="text-3xl font-serif text-amber-400">ح</span>
      </motion.div>

      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-2xl md:text-3xl font-serif text-amber-100 tracking-wide mb-2"
      >
        {lang === 'ar' ? 'الساعة القديمة في حمص' : 'The Old Clock of Homs'}
      </motion.h1>

      <p className="text-xs md:text-sm text-amber-400/80 tracking-widest mb-8">
        {lang === 'ar' ? 'جاري تحميل التجربة ثلاثية الأبعاد...' : 'Loading 3D Experience...'}
      </p>

      {/* Progress Bar Container */}
      <div className="w-64 md:w-80 h-1.5 bg-[#1e1b18] rounded-full overflow-hidden border border-amber-900/30 relative">
        <motion.div
          className="h-full bg-gradient-to-r from-amber-600 via-amber-400 to-yellow-200"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="mt-3 text-xs text-stone-500 font-mono tracking-wider">
        {progress}%
      </div>
    </motion.div>
  );
}

export function HeroOverlay({ onExplore, lang = 'ar', t }) {
  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-6 md:p-12">
      {/* Top Tagline */}
      <motion.div
        initial={{ y: -30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, delay: 0.3 }}
        className="self-center text-center mt-12 md:mt-8"
      >
        <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider text-amber-400 bg-amber-950/40 border border-amber-500/30 backdrop-blur-md shadow-lg">
          {t.hero.tagline}
        </span>
      </motion.div>

      {/* Main Title Banner */}
      <motion.div
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, delay: 0.6 }}
        className="self-center text-center max-w-3xl pointer-events-auto my-auto"
      >
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-transparent bg-clip-text bg-gradient-to-r from-amber-100 via-amber-300 to-amber-500 drop-shadow-[0_5px_15px_rgba(0,0,0,0.8)] mb-4 tracking-tight leading-tight">
          {t.hero.heading}
        </h1>
        <p className="text-lg md:text-2xl text-amber-200/90 font-serif italic mb-6 leading-relaxed">
          {t.subtitle}
        </p>
        <p className="text-sm md:text-base text-stone-300 max-w-xl mx-auto mb-8 font-light leading-relaxed">
          {t.hero.subheading}
        </p>

        {/* CTA Button */}
        <motion.button
          onClick={onExplore}
          whileHover={{ scale: 1.05, boxShadow: '0 0 25px rgba(245,158,11,0.5)' }}
          whileTap={{ scale: 0.95 }}
          className="px-8 py-4 rounded-full bg-gradient-to-r from-amber-600 via-amber-500 to-amber-700 text-stone-950 font-bold text-base md:text-lg shadow-[0_0_20px_rgba(217,119,6,0.3)] transition-all cursor-pointer flex items-center justify-center gap-3 mx-auto border border-amber-300/40"
        >
          <span>{t.hero.explore}</span>
          <svg className="w-5 h-5 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
          </svg>
        </motion.button>
      </motion.div>

      {/* Scroll Down Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="self-center text-center mb-4 flex flex-col items-center gap-2"
      >
        <span className="text-xs text-stone-400 tracking-widest uppercase">
          {lang === 'ar' ? 'تمرير للاستكشاف' : 'Scroll to Explore'}
        </span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.8 }}
          className="w-5 h-8 rounded-full border-2 border-amber-500/40 flex justify-center p-1"
        >
          <div className="w-1 h-2 bg-amber-400 rounded-full" />
        </motion.div>
      </motion.div>
    </div>
  );
}
