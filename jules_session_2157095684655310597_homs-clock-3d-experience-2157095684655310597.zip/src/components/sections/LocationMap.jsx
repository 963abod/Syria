import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';

function Globe3D({ zoomStage }) {
  // Zoom scale and rotation based on stage (0: Syria, 1: Homs City, 2: Clock Square)
  const scale = zoomStage === 0 ? 1 : zoomStage === 1 ? 2.2 : 4.5;
  const positionY = zoomStage === 0 ? 0 : zoomStage === 1 ? -0.5 : -1.8;

  return (
    <group position={[0, positionY, 0]} scale={[scale, scale, scale]}>
      {/* Globe / Map Base Disc */}
      <mesh rotation={[-Math.PI / 3, 0, 0]}>
        <cylinderGeometry args={[2.5, 2.5, 0.1, 64]} />
        <meshStandardMaterial color="#12100e" roughness={0.7} metalness={0.3} />
      </mesh>

      {/* Grid Lines for 3D Dark Map aesthetic */}
      <mesh rotation={[-Math.PI / 3, 0, 0]} position={[0, 0.06, 0]}>
        <ringGeometry args={[0.5, 2.4, 32]} />
        <meshBasicMaterial color="#d97706" wireframe opacity={0.25} transparent />
      </mesh>

      {/* Syria Outline Marker Area */}
      <mesh position={[0, 0.1, 0]} rotation={[-Math.PI / 3, 0, 0]}>
        <circleGeometry args={[1.2, 32]} />
        <meshStandardMaterial color="#2d2215" transparent opacity={0.6} />
      </mesh>

      {/* Glowing Pin Marker for Homs Clock Tower (34.7297° N, 36.7183° E) */}
      <group position={[0.1, 0.4, 0.1]}>
        <mesh>
          <sphereGeometry args={[0.08, 16, 16]} />
          <meshBasicMaterial color="#f59e0b" />
        </mesh>
        <mesh position={[0, 0.3, 0]}>
          <cylinderGeometry args={[0.01, 0.01, 0.6]} />
          <meshBasicMaterial color="#f59e0b" />
        </mesh>
        {/* Pulsing Light Ring */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.1, 0.25, 32]} />
          <meshBasicMaterial color="#f59e0b" transparent opacity={0.7} />
        </mesh>
      </group>
    </group>
  );
}

export function LocationMap({ t, lang }) {
  const [zoomStage, setZoomStage] = useState(0);

  const stages = [
    { name: t.location.syria, desc: '34°50′N 38°30′E' },
    { name: t.location.homs, desc: '34°44′N 36°43′E' },
    { name: t.location.square, desc: t.location.coords },
  ];

  return (
    <section id="location" className="relative min-h-screen py-24 px-6 md:px-12 bg-[#0a0908] flex flex-col justify-center border-t border-amber-900/20">
      <div className="max-w-6xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Information Panel */}
        <div className="z-10">
          <span className="text-amber-500 font-semibold text-xs tracking-widest uppercase mb-2 block">
            {lang === 'ar' ? 'الخريطة التفاعلية' : 'Interactive Map'}
          </span>
          <h2 className="text-3xl md:text-5xl font-serif text-amber-100 mb-4 leading-tight">
            {t.location.title}
          </h2>
          <p className="text-stone-400 text-sm md:text-base mb-8 leading-relaxed">
            {t.location.desc}
          </p>

          {/* Interactive Zoom Controls */}
          <div className="flex flex-wrap gap-3 mb-8">
            {stages.map((stg, idx) => (
              <button
                key={idx}
                onClick={() => setZoomStage(idx)}
                className={`px-5 py-2.5 rounded-full text-xs md:text-sm font-semibold transition-all cursor-pointer border ${
                  zoomStage === idx
                    ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                    : 'bg-stone-900/60 text-stone-300 border-stone-800 hover:border-amber-500/50'
                }`}
              >
                {stg.name}
              </button>
            ))}
          </div>

          {/* Location Metadata Card */}
          <div className="p-6 rounded-2xl bg-stone-900/40 border border-amber-500/20 backdrop-blur-md">
            <div className="text-xs text-amber-400/80 mb-1">{t.location.subtitle}</div>
            <div className="text-lg md:text-xl font-serif text-amber-100 mb-2">
              {stages[zoomStage].name}
            </div>
            <div className="text-xs font-mono text-stone-400 mb-6">
              {stages[zoomStage].desc}
            </div>

            <a
              href="https://maps.app.goo.gl/gDNKcB3sKa8T1mCZ7"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 text-stone-950 font-bold text-xs md:text-sm shadow-md hover:brightness-110 transition-all"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
              </svg>
              <span>{t.location.googleMapsBtn}</span>
            </a>
          </div>
        </div>

        {/* 3D Map Viewport */}
        <div className="h-[380px] md:h-[500px] w-full rounded-3xl overflow-hidden border border-amber-500/30 relative bg-[#060504] shadow-2xl">
          <Canvas camera={{ position: [0, 4, 5], fov: 45 }}>
            <ambientLight intensity={0.6} />
            <directionalLight position={[5, 10, 5]} intensity={1.5} color="#fbbf24" />
            <Globe3D zoomStage={zoomStage} />
            <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
          </Canvas>

          {/* Map Overlay Badge */}
          <div className="absolute top-4 left-4 right-4 flex justify-between items-center pointer-events-none">
            <span className="text-[10px] uppercase tracking-widest text-amber-400/70 bg-stone-900/80 px-3 py-1 rounded-full border border-amber-500/20">
              3D Interactive Coordinate Mapping
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
