import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { ClockTower } from '../3d/ClockTower';
import { AtmosphericParticles, CinematicLighting } from '../3d/Atmosphere';

export function CloserInspection({ t, lang }) {
  const [selectedHotspot, setSelectedHotspot] = useState(null);

  const hotspots = t.inspection.hotspots;

  const handleHotspotClick = (id) => {
    const found = hotspots.find((h) => h.id === id);
    setSelectedHotspot(found);
  };

  return (
    <section id="inspection" className="relative min-h-screen py-24 px-6 md:px-12 bg-[#08080a] flex flex-col justify-center border-t border-amber-900/20">
      <div className="max-w-6xl mx-auto w-full">
        <div className="text-center mb-12">
          <span className="text-amber-500 font-semibold text-xs tracking-widest uppercase mb-2 block">
            {lang === 'ar' ? 'الاستكشاف الدقيق' : '3D Mechanical Breakdown'}
          </span>
          <h2 className="text-3xl md:text-5xl font-serif text-amber-100 mb-4">
            {t.inspection.title}
          </h2>
          <p className="text-stone-400 text-sm md:text-base max-w-xl mx-auto">
            {t.inspection.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
          {/* 3D Model Inspection Viewport */}
          <div className="lg:col-span-2 h-[450px] md:h-[550px] rounded-3xl overflow-hidden border border-amber-500/30 relative bg-[#050404] shadow-2xl">
            <Canvas camera={{ position: [0, 1.5, 6.5], fov: 45 }}>
              <CinematicLighting />
              <ClockTower onHotspotClick={handleHotspotClick} />
              <AtmosphericParticles count={180} />
              <OrbitControls enableZoom={true} minDistance={3} maxDistance={10} />
            </Canvas>

            <div className="absolute top-4 left-4 right-4 flex justify-between items-center pointer-events-none">
              <span className="text-[10px] text-amber-400 bg-stone-900/80 px-3 py-1 rounded-full border border-amber-500/20">
                {t.inspection.instructions}
              </span>
            </div>
          </div>

          {/* Hotspot Info Panel */}
          <div className="flex flex-col gap-4">
            <div className="text-xs text-amber-400/80 font-semibold tracking-wider uppercase mb-1">
              {lang === 'ar' ? 'اختر جزأً لاستكشاف التفاصيل:' : 'Select a component to inspect:'}
            </div>

            {/* Hotspot Selector Buttons */}
            <div className="grid grid-cols-2 gap-2 mb-2">
              {hotspots.map((spot) => {
                const isSelected = selectedHotspot?.id === spot.id;
                return (
                  <button
                    key={spot.id}
                    onClick={() => setSelectedHotspot(spot)}
                    className={`p-3 rounded-xl text-xs font-semibold transition-all cursor-pointer border text-start ${
                      isSelected
                        ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                        : 'bg-stone-900/60 text-stone-300 border-stone-800 hover:border-amber-500/50'
                    }`}
                  >
                    {spot.title}
                  </button>
                );
              })}
            </div>

            {/* Selected Hotspot Detail Card */}
            <AnimatePresence mode="wait">
              {selectedHotspot ? (
                <motion.div
                  key={selectedHotspot.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="p-6 rounded-2xl bg-gradient-to-b from-stone-900/90 to-[#12100e] border border-amber-500/30 backdrop-blur-md shadow-xl"
                >
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-xs text-amber-400 font-mono">
                      HOTSPOT // {selectedHotspot.id.toUpperCase()}
                    </span>
                    <button
                      onClick={() => setSelectedHotspot(null)}
                      className="text-stone-400 hover:text-amber-400 text-xs"
                    >
                      ✕
                    </button>
                  </div>
                  <h3 className="text-xl font-serif text-amber-100 mb-3">
                    {selectedHotspot.title}
                  </h3>
                  <p className="text-stone-300 text-xs md:text-sm leading-relaxed font-light">
                    {selectedHotspot.desc}
                  </p>
                </motion.div>
              ) : (
                <div className="p-8 rounded-2xl bg-stone-900/30 border border-stone-800 text-center text-stone-500 text-xs">
                  {lang === 'ar'
                    ? 'اضغط على أي جزء في القائمة أو على النقاط الصفراء المضيئة في الساعة للمعاينة'
                    : 'Click any component above or interact with glowing hotspots on the model'}
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
