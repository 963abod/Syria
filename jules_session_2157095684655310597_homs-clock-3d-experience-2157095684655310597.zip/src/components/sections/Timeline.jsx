import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export function HistoricalTimeline({ t, lang }) {
  const [activeIdx, setActiveIdx] = useState(0);

  const events = t.timeline.events;

  return (
    <section id="timeline" className="relative min-h-screen py-24 px-6 md:px-12 bg-[#08080a] flex flex-col justify-center border-t border-amber-900/20 overflow-hidden">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-600/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-5xl mx-auto w-full z-10">
        {/* Header Title */}
        <div className="text-center mb-16">
          <span className="text-amber-500 font-semibold text-xs tracking-widest uppercase mb-2 block">
            {lang === 'ar' ? 'الجدول الزمني التفاعلي' : 'Interactive Timeline'}
          </span>
          <h2 className="text-3xl md:text-5xl font-serif text-amber-100 mb-4">
            {t.timeline.title}
          </h2>
          <p className="text-stone-400 text-sm md:text-base max-w-xl mx-auto">
            {t.timeline.subtitle}
          </p>
        </div>

        {/* Timeline Horizontal Year Slider */}
        <div className="relative mb-16">
          {/* Connector Line */}
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-stone-800 -translate-y-1/2 z-0" />

          <div className="flex justify-between items-center relative z-10 max-w-3xl mx-auto">
            {events.map((evt, idx) => {
              const isActive = idx === activeIdx;
              return (
                <button
                  key={idx}
                  onClick={() => setActiveIdx(idx)}
                  className="flex flex-col items-center group cursor-pointer focus:outline-none"
                >
                  <motion.div
                    animate={{
                      scale: isActive ? 1.25 : 1,
                      backgroundColor: isActive ? '#f59e0b' : '#1c1917',
                      borderColor: isActive ? '#fef08a' : '#78350f',
                    }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                    className="w-10 h-10 md:w-12 md:h-12 rounded-full border-2 flex items-center justify-center shadow-lg transition-colors"
                  >
                    <span className={`text-xs md:text-sm font-bold font-serif ${isActive ? 'text-stone-950' : 'text-amber-400'}`}>
                      {evt.year}
                    </span>
                  </motion.div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Event Detail Card */}
        <div className="max-w-2xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeIdx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="p-8 md:p-10 rounded-3xl bg-gradient-to-b from-stone-900/80 to-[#12100e]/90 border border-amber-500/30 backdrop-blur-xl shadow-[0_10px_30px_rgba(0,0,0,0.8)] relative overflow-hidden"
            >
              {/* Year Stamp */}
              <div className="text-5xl md:text-7xl font-serif text-amber-500/10 absolute -top-2 -right-2 font-bold pointer-events-none select-none">
                {events[activeIdx].year}
              </div>

              <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-amber-400 bg-amber-950/60 border border-amber-500/30 mb-4">
                {events[activeIdx].year}
              </div>

              <h3 className="text-2xl md:text-3xl font-serif text-amber-100 mb-4">
                {events[activeIdx].title}
              </h3>

              <p className="text-stone-300 text-sm md:text-base leading-relaxed font-light">
                {events[activeIdx].desc}
              </p>

              {/* Navigation Arrows */}
              <div className="flex justify-between items-center mt-8 pt-6 border-t border-stone-800">
                <button
                  disabled={activeIdx === 0}
                  onClick={() => setActiveIdx((prev) => Math.max(0, prev - 1))}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-300 hover:text-amber-400 disabled:opacity-30 disabled:hover:text-stone-300 flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <svg className="w-4 h-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
                  </svg>
                  <span>{lang === 'ar' ? 'السابق' : 'Previous'}</span>
                </button>

                <div className="text-xs text-stone-500 font-mono">
                  {activeIdx + 1} / {events.length}
                </div>

                <button
                  disabled={activeIdx === events.length - 1}
                  onClick={() => setActiveIdx((prev) => Math.min(events.length - 1, prev + 1))}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-300 hover:text-amber-400 disabled:opacity-30 disabled:hover:text-stone-300 flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <span>{lang === 'ar' ? 'التالي' : 'Next'}</span>
                  <svg className="w-4 h-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
