import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { ClockTower } from '../3d/ClockTower';
import { AtmosphericParticles, VolumetricFogPlanes } from '../3d/Atmosphere';

function OldSquareEnvironment() {
  const bannersRef = useRef();

  const stoneMaterial = new THREE.MeshStandardMaterial({
    color: '#262422',
    roughness: 0.9,
  });

  const woodMaterial = new THREE.MeshStandardMaterial({
    color: '#451a03',
    roughness: 0.8,
  });

  const bannerMaterial = new THREE.MeshStandardMaterial({
    color: '#7f1d1d',
    roughness: 0.6,
    side: THREE.DoubleSide,
  });

  // Animated swaying banners in wind
  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    if (bannersRef.current) {
      bannersRef.current.children.forEach((b, i) => {
        b.rotation.z = Math.sin(time * 2 + i) * 0.08;
      });
    }
  });

  return (
    <group>
      {/* Cobblestone Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -4.0, 0]} receiveShadow>
        <planeGeometry args={[30, 30]} />
        <meshStandardMaterial color="#171614" roughness={0.95} />
      </mesh>

      {/* Surrounding Old Homs Archways & Buildings */}
      {/* Left Building */}
      <mesh position={[-6, -1, -2]} material={stoneMaterial} castShadow>
        <boxGeometry args={[4, 6, 8]} />
      </mesh>
      {/* Archway Cutout */}
      <mesh position={[-4.1, -2.5, 0]} material={stoneMaterial}>
        <boxGeometry args={[0.5, 3, 2.5]} />
      </mesh>

      {/* Right Building */}
      <mesh position={[6, -1, -2]} material={stoneMaterial} castShadow>
        <boxGeometry args={[4, 6, 8]} />
      </mesh>

      {/* Distant Silhouettes */}
      <mesh position={[0, 0, -12]} material={stoneMaterial}>
        <boxGeometry args={[22, 8, 1]} />
      </mesh>

      {/* Warm Window Glow Lights */}
      <pointLight position={[-4.5, 0, 1]} color="#f59e0b" intensity={2} distance={5} />
      <pointLight position={[4.5, 0, 1]} color="#f59e0b" intensity={2} distance={5} />

      {/* Swaying Heritage Banners */}
      <group ref={bannersRef}>
        <mesh position={[-3.8, 1.5, 1.5]} material={bannerMaterial}>
          <planeGeometry args={[0.6, 1.5]} />
        </mesh>
        <mesh position={[3.8, 1.5, 1.5]} material={bannerMaterial}>
          <planeGeometry args={[0.6, 1.5]} />
        </mesh>
      </group>
    </group>
  );
}

export function HistoricalScene({ t, lang }) {
  return (
    <section id="scene" className="relative min-h-screen py-24 px-6 md:px-12 bg-[#060504] flex flex-col justify-center border-t border-amber-900/20">
      <div className="max-w-6xl mx-auto w-full">
        <div className="text-center mb-12">
          <span className="text-amber-500 font-semibold text-xs tracking-widest uppercase mb-2 block">
            {lang === 'ar' ? 'البيئة ثلاثية الأبعاد' : '3D Environment'}
          </span>
          <h2 className="text-3xl md:text-5xl font-serif text-amber-100 mb-4">
            {t.scene.title}
          </h2>
          <p className="text-stone-400 text-sm md:text-base max-w-2xl mx-auto">
            {t.scene.subtitle}
          </p>
        </div>

        {/* 3D Scene Canvas */}
        <div className="h-[450px] md:h-[600px] w-full rounded-3xl overflow-hidden border border-amber-500/30 relative shadow-[0_0_50px_rgba(0,0,0,0.9)] bg-[#040303]">
          <Canvas camera={{ position: [0, 1, 9], fov: 50 }}>
            <ambientLight intensity={0.5} />
            <directionalLight position={[10, 15, 10]} intensity={1.8} color="#fbbf24" castShadow />
            <directionalLight position={[-10, 10, -5]} intensity={0.6} color="#38bdf8" />

            <ClockTower />
            <OldSquareEnvironment />
            <AtmosphericParticles count={200} />
            <VolumetricFogPlanes />

            <OrbitControls
              enableZoom={true}
              maxPolarAngle={Math.PI / 2 - 0.05}
              minDistance={4}
              maxDistance={14}
            />
          </Canvas>

          {/* Interactive Hint Banner */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 px-5 py-2.5 rounded-full bg-stone-900/80 border border-amber-500/30 text-amber-400 text-xs font-semibold backdrop-blur-md pointer-events-none shadow-lg flex items-center gap-2">
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
            <span>{lang === 'ar' ? 'اسحب بالماوس أو الإصبع للاستكشاف والتدوير' : 'Drag mouse or touch to rotate & explore'}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
