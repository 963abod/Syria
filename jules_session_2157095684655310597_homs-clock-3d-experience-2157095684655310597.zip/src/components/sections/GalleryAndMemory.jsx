import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export function HistoricalGallery({ t, lang }) {
  const [activeImage, setActiveImage] = useState(null);

  const images = t.gallery.images;

  return (
    <section id="gallery" className="relative min-h-screen py-24 px-6 md:px-12 bg-[#060504] flex flex-col justify-center border-t border-amber-900/20">
      <div className="max-w-6xl mx-auto w-full">
        <div className="text-center mb-16">
          <span className="text-amber-500 font-semibold text-xs tracking-widest uppercase mb-2 block">
            {lang === 'ar' ? 'معرض الأرشيف الرقمي' : '3D Historical Gallery'}
          </span>
          <h2 className="text-3xl md:text-5xl font-serif text-amber-100 mb-4">
            {t.gallery.title}
          </h2>
          <p className="text-stone-400 text-sm md:text-base max-w-xl mx-auto">
            {t.gallery.subtitle}
          </p>
        </div>

        {/* 3D Floating Image Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {images.map((img, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -10, scale: 1.02 }}
              transition={{ duration: 0.3 }}
              onClick={() => setActiveImage(img)}
              className="group relative rounded-2xl overflow-hidden border border-amber-500/20 bg-stone-900/40 cursor-pointer shadow-xl backdrop-blur-md"
            >
              <div className="h-64 overflow-hidden relative">
                <img
                  src={img.url}
                  alt={img.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 brightness-90 group-hover:brightness-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#08080a] via-transparent to-transparent opacity-80" />
              </div>

              <div className="p-5 relative z-10">
                <span className="text-[10px] text-amber-400 font-mono block mb-1">
                  {img.date}
                </span>
                <h3 className="text-lg font-serif text-amber-100 group-hover:text-amber-400 transition-colors line-clamp-1">
                  {img.title}
                </h3>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* High-Resolution Lightbox Modal */}
      <AnimatePresence>
        {activeImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActiveImage(null)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="max-w-3xl w-full rounded-3xl overflow-hidden border border-amber-500/40 bg-stone-950 p-6 shadow-2xl relative"
            >
              <button
                onClick={() => setActiveImage(null)}
                className="absolute top-4 right-4 text-stone-400 hover:text-amber-400 text-lg w-10 h-10 rounded-full bg-stone-900 border border-stone-800 flex items-center justify-center z-10"
              >
                ✕
              </button>

              <div className="h-[350px] md:h-[450px] rounded-2xl overflow-hidden mb-6 relative">
                <img
                  src={activeImage.url}
                  alt={activeImage.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div>
                <span className="text-xs text-amber-400 font-mono mb-1 block">
                  {activeImage.date} • {activeImage.source}
                </span>
                <h3 className="text-2xl font-serif text-amber-100 mb-2">
                  {activeImage.title}
                </h3>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

export function MemorySection({ t, lang }) {
  return (
    <section id="memory" className="relative min-h-screen py-32 px-6 md:px-12 bg-[#08080a] flex flex-col justify-center items-center text-center border-t border-amber-900/20 overflow-hidden">
      {/* Deep Foggy Atmospheric Glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#060504] via-[#0c0a08] to-[#08080a] opacity-90" />

      <div className="max-w-3xl mx-auto relative z-10">
        <span className="text-amber-500 font-semibold text-xs tracking-widest uppercase mb-4 block">
          {lang === 'ar' ? 'ذاكرة حمص العدية' : 'Memory of the City'}
        </span>

        <h2 className="text-4xl md:text-6xl font-serif text-amber-100 mb-10 leading-tight">
          {t.memory.title}
        </h2>

        <div className="space-y-8 text-stone-300 text-base md:text-xl font-serif leading-relaxed italic">
          <p className="border-s-2 border-amber-500/50 ps-6 text-start">
            "{t.memory.p1}"
          </p>
          <p className="border-s-2 border-amber-500/50 ps-6 text-start">
            "{t.memory.p2}"
          </p>
          <p className="border-s-2 border-amber-500/50 ps-6 text-start">
            "{t.memory.p3}"
          </p>
        </div>
      </div>
    </section>
  );
}
