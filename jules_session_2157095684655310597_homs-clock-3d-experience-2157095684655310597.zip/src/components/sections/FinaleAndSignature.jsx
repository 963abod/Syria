import React from 'react';
import { motion } from 'framer-motion';

export function FinaleAndSignature({ t, lang }) {
  return (
    <footer className="relative min-h-[80vh] py-24 px-6 md:px-12 bg-[#040303] flex flex-col justify-between items-center text-center border-t border-amber-900/30 overflow-hidden">
      {/* Dynamic Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-amber-600/10 rounded-full blur-[160px] pointer-events-none" />

      {/* Camera Pullback Quote */}
      <div className="my-auto max-w-3xl z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
        >
          <span className="text-amber-500 font-serif text-xl md:text-2xl block mb-4">
            {t.title}
          </span>
          <h2 className="text-3xl md:text-5xl font-serif text-amber-100 tracking-wide mb-6 leading-tight">
            "{t.finale.quote}"
          </h2>
          <div className="w-24 h-0.5 bg-gradient-to-r from-transparent via-amber-500 to-transparent mx-auto" />
        </motion.div>
      </div>

      {/* Prominent Signature: "صناعة وتصميم عبود" / "Designed & Created by Aboud" */}
      <div className="w-full z-10 pt-16 border-t border-amber-900/20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="flex flex-col items-center gap-3"
        >
          {/* Main Metallic Glowing Branding */}
          <div className="px-8 py-4 rounded-3xl bg-gradient-to-r from-amber-950/60 via-[#1c1917]/80 to-amber-950/60 border border-amber-500/40 shadow-[0_0_30px_rgba(217,119,6,0.25)] backdrop-blur-lg">
            <span className="text-2xl md:text-3xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500 animate-copper-glow tracking-wider block">
              {t.finale.credits}
            </span>
            <span className="text-xs md:text-sm text-amber-300/80 tracking-widest font-mono mt-1 block">
              {t.finale.subCredits}
            </span>
          </div>

          <p className="text-xs text-stone-500 mt-4">
            © {new Date().getFullYear()} {t.title} • {lang === 'ar' ? 'جميع الحقوق محفوظة' : 'All Rights Reserved'}
          </p>
        </motion.div>
      </div>
    </footer>
  );
}
