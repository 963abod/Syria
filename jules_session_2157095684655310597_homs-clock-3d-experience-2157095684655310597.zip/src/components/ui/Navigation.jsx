import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export function Navigation({ lang, setLang, isMuted, onToggleSound, t }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'hero', label: t.nav.hero },
    { id: 'location', label: t.nav.location },
    { id: 'timeline', label: t.nav.timeline },
    { id: 'scene', label: t.nav.scene },
    { id: 'inspection', label: t.nav.inspection },
    { id: 'gallery', label: t.nav.gallery },
    { id: 'memory', label: t.nav.memory },
  ];

  const scrollToSection = (id) => {
    setMobileMenuOpen(false);
    if (id === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-black/60 backdrop-blur-xl border-b border-amber-500/20 py-3 shadow-xl'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Brand Logo Header */}
        <button
          onClick={() => scrollToSection('hero')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-full border border-amber-500/40 bg-gradient-to-br from-amber-950 to-stone-900 flex items-center justify-center text-amber-400 font-serif font-bold text-lg group-hover:scale-105 transition-transform">
            ح
          </div>
          <span className="font-serif font-bold text-base md:text-lg text-amber-100 group-hover:text-amber-400 transition-colors">
            {t.title}
          </span>
        </button>

        {/* Desktop Links */}
        <nav className="hidden lg:flex items-center gap-6">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => scrollToSection(link.id)}
              className="text-xs font-semibold text-stone-300 hover:text-amber-400 transition-colors cursor-pointer"
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Audio Sound Toggle & Language Switcher */}
        <div className="flex items-center gap-3">
          {/* Sound Button */}
          <button
            onClick={onToggleSound}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer border ${
              !isMuted
                ? 'bg-amber-500/20 text-amber-400 border-amber-500/40 shadow-[0_0_12px_rgba(245,158,11,0.2)]'
                : 'bg-stone-900/80 text-stone-400 border-stone-800'
            }`}
          >
            <span>{!isMuted ? '🔊' : '🔇'}</span>
            <span className="hidden sm:inline">
              {!isMuted ? t.audio.soundOn : t.audio.soundOff}
            </span>
          </button>

          {/* Language Switch Button */}
          <button
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            className="px-3 py-1.5 rounded-full text-xs font-semibold text-stone-200 bg-stone-900/80 border border-stone-800 hover:border-amber-500/40 transition-all cursor-pointer font-mono"
          >
            {lang === 'ar' ? 'EN' : 'عربي'}
          </button>

          {/* Mobile Hamburger Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-amber-400 cursor-pointer"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#0a0908]/95 border-b border-amber-500/30 backdrop-blur-2xl overflow-hidden"
          >
            <div className="p-6 flex flex-col gap-4 text-start">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="text-sm font-semibold text-stone-200 hover:text-amber-400 py-2 border-b border-stone-800/60 transition-colors text-start"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
