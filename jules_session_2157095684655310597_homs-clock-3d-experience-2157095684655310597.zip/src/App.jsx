import React, { useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { content } from './data/content';
import { soundEngine } from './utils/soundEngine';
import { ClockTower } from './components/3d/ClockTower';
import { AtmosphericParticles, VolumetricFogPlanes, CinematicLighting } from './components/3d/Atmosphere';
import { LoadingScreen, HeroOverlay } from './components/sections/Hero';
import { LocationMap } from './components/sections/LocationMap';
import { HistoricalTimeline } from './components/sections/Timeline';
import { HistoricalScene } from './components/sections/HistoricalScene';
import { CloserInspection } from './components/sections/CloserInspection';
import { HistoricalGallery, MemorySection } from './components/sections/GalleryAndMemory';
import { FinaleAndSignature } from './components/sections/FinaleAndSignature';
import { Navigation } from './components/ui/Navigation';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [lang, setLang] = useState('ar');
  const [isMuted, setIsMuted] = useState(true);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const t = content[lang];

  // Mouse parallax motion listener
  useEffect(() => {
    const handleMouseMove = (e) => {
      const x = (e.clientX / window.innerWidth) * 2 - 1;
      const y = -(e.clientY / window.innerHeight) * 2 + 1;
      setMousePos({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Update document language direction (RTL/LTR)
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const handleToggleSound = () => {
    const state = soundEngine.toggleSound();
    setIsMuted(!state);
  };

  const handleExplore = () => {
    const locSec = document.getElementById('location');
    if (locSec) {
      locSec.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#08080a] text-stone-200 overflow-x-hidden selection:bg-amber-500 selection:text-stone-950 font-sans">
      {/* Loading Screen */}
      {loading && <LoadingScreen onComplete={() => setLoading(false)} lang={lang} />}

      {/* Glassmorphism Header Bar */}
      <Navigation
        lang={lang}
        setLang={setLang}
        isMuted={isMuted}
        onToggleSound={handleToggleSound}
        t={t}
      />

      {/* Hero Section with 3D Canvas */}
      <section id="hero" className="relative h-screen w-full overflow-hidden bg-[#060504]">
        <Canvas camera={{ position: [0, 0.5, 7], fov: 45 }}>
          <CinematicLighting mousePos={mousePos} />
          <ClockTower />
          <AtmosphericParticles count={300} mousePos={mousePos} />
          <VolumetricFogPlanes mousePos={mousePos} />
        </Canvas>

        {/* Hero Overlay Text & CTA */}
        <HeroOverlay onExplore={handleExplore} lang={lang} t={t} />
      </section>

      {/* Location Map Section */}
      <LocationMap t={t} lang={lang} />

      {/* Historical Timeline Section */}
      <HistoricalTimeline t={t} lang={lang} />

      {/* 3D Historical Square Reconstruction Section */}
      <HistoricalScene t={t} lang={lang} />

      {/* Closer Inspection Section */}
      <CloserInspection t={t} lang={lang} />

      {/* Historical Photo Gallery Section */}
      <HistoricalGallery t={t} lang={lang} />

      {/* Memory of the City Section */}
      <MemorySection t={t} lang={lang} />

      {/* Finale & Custom "صناعة وتصميم عبود" Signature Footer */}
      <FinaleAndSignature t={t} lang={lang} />
    </div>
  );
}
