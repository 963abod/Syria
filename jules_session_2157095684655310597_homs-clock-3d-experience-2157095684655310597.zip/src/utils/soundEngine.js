// Web Audio API Ambient & Clock Sound Synthesizer
// Provides zero-dependency procedural audio for ticks, bell chimes, ambient wind, and UI clicks.

class SoundEngine {
  constructor() {
    this.ctx = null;
    this.isMuted = true;
    this.ambientGain = null;
    this.windOsc = null;
    this.tickInterval = null;
    this.isInitialized = false;
  }

  init() {
    if (this.isInitialized) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      this.ctx = new AudioContext();
      this.isInitialized = true;
    } catch (e) {
      console.warn('Web Audio API not supported', e);
    }
  }

  toggleSound(forceState) {
    if (!this.isInitialized) this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    if (forceState !== undefined) {
      this.isMuted = !forceState;
    } else {
      this.isMuted = !this.isMuted;
    }

    if (!this.isMuted) {
      this.startAmbientWind();
      this.startTicking();
      this.playChime(440, 1.2);
    } else {
      this.stopAmbientWind();
      this.stopTicking();
    }

    return !this.isMuted;
  }

  // Realistic mechanical clock tick using noise and bandpass filter
  playTick() {
    if (this.isMuted || !this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      // Short click/tick buffer
      const bufferSize = this.ctx.sampleRate * 0.015; // 15ms
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = buffer.getChannelData(0);

      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.2));
      }

      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1800 + Math.random() * 200, now);
      filter.Q.setValueAtTime(4.0, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.015);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + 0.015);
    } catch (e) {
      // Audio fallback
    }
  }

  // Clock bell chime with warm harmonic overtones
  playChime(freq = 523.25, duration = 2.5) {
    if (this.isMuted || !this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc2.type = 'triangle';

      osc.frequency.setValueAtTime(freq, now);
      osc2.frequency.setValueAtTime(freq * 2.01, now); // Metallic overtone

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc2.start(now);
      osc.stop(now + duration);
      osc2.stop(now + duration);
    } catch (e) {
      // Audio fallback
    }
  }

  // Subtle wind/ambient rumble synthesizer
  startAmbientWind() {
    if (!this.ctx || this.windOsc) return;

    try {
      const now = this.ctx.currentTime;
      const bufferSize = 2 * this.ctx.sampleRate;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);

      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      this.windSource = this.ctx.createBufferSource();
      this.windSource.buffer = noiseBuffer;
      this.windSource.loop = true;

      this.windFilter = this.ctx.createBiquadFilter();
      this.windFilter.type = 'lowpass';
      this.windFilter.frequency.setValueAtTime(220, now);

      this.ambientGain = this.ctx.createGain();
      this.ambientGain.gain.setValueAtTime(0.03, now);

      this.windSource.connect(this.windFilter);
      this.windFilter.connect(this.ambientGain);
      this.ambientGain.connect(this.ctx.destination);

      this.windSource.start(now);
    } catch (e) {
      // Audio fallback
    }
  }

  stopAmbientWind() {
    if (this.windSource) {
      try {
        this.windSource.stop();
        this.windSource.disconnect();
      } catch (e) {}
      this.windSource = null;
    }
  }

  startTicking() {
    if (this.tickInterval) clearInterval(this.tickInterval);
    this.tickInterval = setInterval(() => {
      this.playTick();
    }, 1000);
  }

  stopTicking() {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
      this.tickInterval = null;
    }
  }

  // Hover UI click sound effect
  playHoverSound() {
    if (this.isMuted || !this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(900, now + 0.05);

      gain.gain.setValueAtTime(0.03, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.05);
    } catch (e) {}
  }
}

export const soundEngine = new SoundEngine();
